</div>
<div class="credit">Site built by <a href="https://www.linkedin.com/in/davidsawyer10">David Sawyer</a> and <a href="https://www.linkedin.com/pub/michael-crosby/63/141/259">Michael Crosby</a></div>
<div class="carrots"></div>
<?php wp_footer(); ?>
</body>
</html>
